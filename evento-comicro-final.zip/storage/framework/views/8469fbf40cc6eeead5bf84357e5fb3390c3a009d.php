<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- SEO -->
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>" />
    <link rel="canonical" href="<?php echo $__env->yieldContent('site_url'); ?>" />
    <meta property="og:locale" content="pt_BR" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>" />
    <meta property="og:description" content="<?php echo $__env->yieldContent('meta_description'); ?>" />
    <meta property="og:url" content="<?php echo $__env->yieldContent('site_url'); ?>" />
    <meta property="og:site_name" content="<?php echo $__env->yieldContent('title'); ?>" />
    <meta name="twitter:card" content="summary_large_image" />

    <!-- Styles -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('aos/aos.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/jquery.jConveyorTicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/quero-expor.css')); ?>" rel="stylesheet">
</head>
<body>
    <?php echo $__env->make('front.layouts._partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('front.layouts._partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

<!-- Scripts -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/loopcounter.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.jConveyorTicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>

</html>
<?php /**PATH C:\wamp64\www\evento-comicro\resources\views//front/layouts/template.blade.php ENDPATH**/ ?>