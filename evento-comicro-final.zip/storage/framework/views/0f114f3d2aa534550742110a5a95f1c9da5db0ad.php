<section class="container-fluid palestrantes">

    <div class="container">

        <div class="text-center">
            <h2 data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom">Palestrantes</h2>
            <p data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom">Saiba quem estará presente no Evento</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom">

            <div class="col-6 col-lg-3 mb-3 mb-md-5">
                <div class="card">
                    <div class="img-card" id="img-1">
                        <img src="<?php echo e(asset('img/decio-lima.png')); ?>" alt="Décio Lima, Presidente do Sebrae" title="Décio Lima , Presidente do Sebrae" width="254" height="344" class="img-fluid card-img-top" />
                        <div class="bio flex-column justify-content-center">
                            <h4>Sobre Décio Lima</h4>
                            <p>Natural de Itajaí (SC) e formado em Ciências Sociais e Direito, Décio Lima foi prefeito durante dois mandatos consecutivos da cidade de Blumenau (SC) e teve como marca da sua gestão a implantação de programas de inclusão social e modernização urbana.</p>
                        </div>
                    </div>
                    <div class="card-body text-center">
                        <span class="card-title">Décio Lima</span>
                        <p class="card-text">Presidente do Sebrae</p>
                    </div>
                </div>
            </div><!-- COL -->

            <div class="col-6 col-lg-3 mb-3 mb-md-5">
                <div class="card">
                    <div class="img-card" id="img-2">
                        <img src="<?php echo e(asset('img/bruno-quick.png')); ?>" alt="Bruno Quick Lourenço de Lima" title="Bruno Quick Lourenço de Lima" width="254" height="344" class="img-fluid card-img-top" />
                        <div class="bio flex-column justify-content-center">
                            <h4 class="text-start">Sobre Bruno Quick</h4>
                            <p>Engenheiro civil e especialista em políticas públicas pela Unicamp. Atuou como dirigente no Movimento Associativista Empresarial, foi diretor técnico do Sebrae Minas e gerente da Unidade de Políticas Públicas e Desenvolvimento Territorial do Sebrae Nacional.</p>
                        </div>
                    </div>
                    <div class="card-body text-center">
                        <span class="card-title">Bruno Quick Lourenço de Lima</span>
                        <p class="card-text">Diretor Técnico do Sebrae</p>
                    </div>
                </div>
            </div><!-- COL -->

        </div><!-- ROW -->

        <?php $__env->startComponent('front.layouts._components.btn_inscricao', ['class' => 'd-flex justify-content-center', 'link' => 'https://www.sympla.com.br/evento/comicro-conectando-negocios/2157093', 'rotulo' => 'Garanta sua vaga']); ?>
        <?php echo $__env->renderComponent(); ?>

    </div><!-- CONTAINER -->

</section>
<?php /**PATH C:\wamp64\www\evento-comicro\resources\views/front/layouts/_includes/palestrantes.blade.php ENDPATH**/ ?>