<?php $__env->startSection('title', 'Conectando Negócios | COMICRO'); ?>
<?php $__env->startSection('meta_description', 'Inovações que Impulsionam as Micro e Pequenas Empresas'); ?>
<?php $__env->startSection('site_url', '#'); ?>


<?php $__env->startSection('content'); ?>

    <!------------------- BANNER ---------------------->
    <?php echo $__env->make('front.layouts._includes.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- SOBRE ---------------------->
    <?php echo $__env->make('front.layouts._includes.sobre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- EVENTO ---------------------->
    <?php echo $__env->make('front.layouts._includes.evento', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- PRA QUEM É INDICADO ---------------------->
    <?php echo $__env->make('front.layouts._includes.indicado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- TAGS ---------------------->
    <?php echo $__env->make('front.layouts._includes.tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- PROGRAMAÇÃO ---------------------->
    <?php echo $__env->make('front.layouts._includes.programacao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- PALESTRANTES ---------------------->
    <?php echo $__env->make('front.layouts._includes.palestrantes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- GALERIA DE IMAGENS ---------------------->
    <?php echo $__env->make('front.layouts._includes.galeria', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- NÃO PERCA A CHANCE ---------------------->
    <?php echo $__env->make('front.layouts._includes.chance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- FAQ ---------------------->
    <?php echo $__env->make('front.layouts._includes.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- REALIZAÇÃO ---------------------->
    <?php echo $__env->make('front.layouts._includes.realizacao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- APOIADORES ---------------------->
    <?php echo $__env->make('front.layouts._includes.apoiadores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!------------------- PATROCINADORES ---------------------->



    <!------------------- CONTATOS ---------------------->
    <?php echo $__env->make('front.layouts._includes.contatos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('.front.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\evento-comicro\resources\views/front/index.blade.php ENDPATH**/ ?>