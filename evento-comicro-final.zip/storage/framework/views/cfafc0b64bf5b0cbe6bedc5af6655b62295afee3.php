<section class="container realizacao">

    <h3 class="text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-offset="0">Realização</h3>

    <div class="text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-offset="0">
        <img src="<?php echo e(asset('img/logo-comicro.svg')); ?>" alt="SEBRAE" title="SEBRAE" width="303" height="51" />
    </div>

</section>
<?php /**PATH C:\wamp64\www\evento-comicro\resources\views/front/layouts/_includes/realizacao.blade.php ENDPATH**/ ?>