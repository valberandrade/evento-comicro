<section class="container-fluid px-0 tags">

    <!-- Plugin HTML begin -->
    <div class="js-conveyor-3">
        <ul>
            <li>
                <div class="d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-md-start text-center text-md-start">
                    <img src="<?php echo e(asset('img/star.svg')); ?>" width="50" height="50" />
                    <span>Inovação e<br>transformação digital</span>
                </div>
            </li>
            <li>
                <div class="d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-md-start text-center text-md-start">
                    <img src="<?php echo e(asset('img/star.svg')); ?>" width="50" height="50" />
                    <span>Tendências e<br>estratégias de mercado</span>
                </div>
            </li>
            <li>
                <div class="d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-md-start text-center text-md-start">
                    <img src="<?php echo e(asset('img/star.svg')); ?>" width="50" height="50" />
                    <span>Empreendedorismo</span>
                </div>
            </li>
            <li>
                <div class="d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-md-start text-center text-md-start">
                    <img src="<?php echo e(asset('img/star.svg')); ?>" width="50" height="50" />
                    <span>CRÉDITO, INVESTIMENTO<br>E FINANÇAS</span>
                </div>
            </li>
            <li>
                <div class="d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-md-start text-center text-md-start">
                    <img src="<?php echo e(asset('img/star.svg')); ?>" width="50" height="50" />
                    <span>Liderança e<br>Produtividade</span>
                </div>
            </li>
            <li>
                <div class="d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-md-start text-center text-md-start">
                    <img src="<?php echo e(asset('img/star.svg')); ?>" width="50" height="50" />
                    <span>Sustentabilidade<br>e Meio Ambiente</span>
                </div>
            </li>
            <li>
                <div class="d-flex flex-column flex-md-row align-items-center justify-content-center justify-content-md-start text-center text-md-start">
                    <img src="<?php echo e(asset('img/star.svg')); ?>" width="50" height="50" />
                    <span>Legislação, Desburocratização<br>e Simplificação</span>
                </div>
            </li>
        </ul>
    </div>
    <!-- Plugin HTML end -->














































</section>
<?php /**PATH C:\wamp64\www\evento-comicro\resources\views/front/layouts/_includes/tags.blade.php ENDPATH**/ ?>