<section class="container-fluid duvidas">

    <div class="container">

        <div class="row gx-5">

            <div class="col-md-6 mb-4 mb-md-0">
                <h2>Dúvidas de como Patrocinar?</h2>
            </div><!-- COL -->

            <div class="col-md-6">
                <p>Use this section to describe your company and the products you offer. You could share your company’s story and details about why you are in business.</p>

                <ul>
                    <li>
                        <a href="mailto:comicroParaPatrocionio@comicro.com" target="_blank">E-mail: comicroParaPatrocionio@comicro.com</a>
                    </li>
                    <li>
                        <a href="#" target="_blank">WhatsApp: (81) 99999-9999</a>
                    </li>
                </ul>
            </div><!-- COL -->

        </div><!-- ROW -->

    </div><!-- CONTAINER -->

</section>
<?php /**PATH C:\wamp64\www\evento-comicro\resources\views/front/layouts/_includes/duvidas.blade.php ENDPATH**/ ?>