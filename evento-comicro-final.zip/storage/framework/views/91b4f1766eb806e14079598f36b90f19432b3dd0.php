<section class="container-fluid galeria px-0">

    <!-- Swiper -->
    <div class="swiper mySwiper">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <img src="<?php echo e(asset('img/carrossel/carrossel-1.jpg')); ?>" alt="" title="" width="526" height="215" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo e(asset('img/carrossel/carrossel-2.jpg')); ?>" alt="" title="" width="526" height="215" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo e(asset('img/carrossel/carrossel-3.jpg')); ?>" alt="" title="" width="526" height="215" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo e(asset('img/carrossel/carrossel-4.jpg')); ?>" alt="" title="" width="526" height="215" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo e(asset('img/carrossel/carrossel-5.jpg')); ?>" alt="" title="" width="526" height="215" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo e(asset('img/carrossel/carrossel-6.jpg')); ?>" alt="" title="" width="526" height="215" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo e(asset('img/carrossel/carrossel-7.jpg')); ?>" alt="" title="" width="526" height="215" />
            </div>
        </div>
    </div>

</section>
<?php /**PATH C:\wamp64\www\evento-comicro\resources\views/front/layouts/_includes/galeria.blade.php ENDPATH**/ ?>