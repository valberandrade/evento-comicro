<div class="<?php echo e($class); ?>">
    <a href="<?php echo e($link); ?>" class="btn btn-info btn-inscreva-se text-uppercase fw-bold" target="_blank"><?php echo e($rotulo); ?></a>
</div>
<?php /**PATH C:\wamp64\www\evento-comicro\resources\views/front/layouts/_components/btn_inscricao.blade.php ENDPATH**/ ?>