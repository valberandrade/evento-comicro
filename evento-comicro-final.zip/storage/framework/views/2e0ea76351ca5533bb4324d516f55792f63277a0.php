<footer>

    <div class="container">

        <div class="row d-flex align-items-center">

            <div class="col-md-6 text-center text-md-start mb-4 mb-md-0">
                <div class="copy text-light">
                    © <?php echo date('Y'); ?> Comicro, Inc. - Todos os direitos reservados
                </div>
            </div><!-- COL -->

            <div class="col-md-6">
                <div class="d-flex align-items-center justify-content-center justify-content-md-end">

                    <a href="https://comicro.org.br/" title="Site COMICRO" target="_blank">Site COMICRO</a>

                    <ul class="d-flex">
                        <li>
                            <a href="https://api.whatsapp.com/send?phone=5581981531166&text=Ol%C3%A1,%20gostaria%20de%20mais%20informa%C3%A7%C3%B5es%20sobre%20o%20COMICRO%20Conectando%C2%A0Neg%C3%B3cios" title="Nosso WhatsApp" target="_blank">
                                <img src="<?php echo e(asset('img/icone-whatsapp-footer.svg')); ?>" alt="Nosso WhatsApp" title="Nosso WhatsApp" width="24" height="24" />
                            </a>
                        </li>

                        <li>
                            <a href="https://www.instagram.com/comicrobrasil/" title="Siga-nos no Instagram" target="_blank">
                                <img src="<?php echo e(asset('img/icone-instagram-footer.svg')); ?>" alt="Siga-nos no Instagram" title="Siga-nos no Instagram" width="28" height="28" />
                            </a>
                        </li>

                        <li>
                            <a href="https://www.facebook.com/comicrobrasil" title="Siga-nos no Facebook" target="_blank">
                                <img src="<?php echo e(asset('img/icone-facebook-footer.svg')); ?>" alt="Siga-nos no Facebook" title="Siga-nos no Facebook" width="28" height="28" />
                            </a>
                        </li>

                        <li>
                            <a href="https://www.linkedin.com/company/comicrobrasil/" title="Siga-nos no Linkedin" target="_blank">
                                <img src="<?php echo e(asset('img/icone-linkedin.svg')); ?>" alt="Siga-nos no Linkedin" title="Siga-nos no Linkedin" width="24" height="24" />
                            </a>
                        </li>
                    </ul>
                </div>
            </div><!-- COL -->

        </div><!-- ROW -->

    </div><!-- CONTAINER -->

</footer>
<?php /**PATH C:\wamp64\www\evento-comicro\resources\views/front/layouts/_partials/footer.blade.php ENDPATH**/ ?>