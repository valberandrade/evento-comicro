<section class="container patrocinadores" id="patrocinadores">

    <h3 class="text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom" data-aos-offset="0">Patrocinadores Diamond</h3>

    <ul class="d-flex justify-content-lg-between flex-wrap" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom" data-aos-offset="0">
        <li>
            <img src="{{ asset('img/logos/logo-spotify.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-google.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-uber.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-microsoft.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-shopify.svg') }}" alt="" title="" height="48" />
        </li>
    </ul>

    <h3 class="text-center mt-4" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom" data-aos-offset="0">Patrocinadores Gold</h3>

    <ul class="d-flex justify-content-lg-between flex-wrap" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom" data-aos-offset="0">
        <li>
            <img src="{{ asset('img/logos/logo-adobe.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-paypal.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-amazon.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-asana.svg') }}" alt="" title="" height="48" />
        </li>
    </ul>

    <h3 class="text-center mt-4" data-aos="fade-up" data-aos-duration="1000" data-aos-offset="0">Patrocinadores Silver</h3>

    <ul class="d-flex justify-content-lg-between flex-wrap" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom" data-aos-offset="0">
        <li>
            <img src="{{ asset('img/logos/logo-spotify.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-google.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-uber.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-microsoft.svg') }}" alt="" title="" height="48" />
        </li>

        <li>
            <img src="{{ asset('img/logos/logo-shopify.svg') }}" alt="" title="" height="48" />
        </li>
    </ul>

</section>
