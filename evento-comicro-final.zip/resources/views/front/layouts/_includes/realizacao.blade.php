<section class="container realizacao">

    <h3 class="text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-offset="0">Realização</h3>

    <div class="text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-offset="0">
        <img src="{{ asset('img/logo-comicro.svg') }}" alt="SEBRAE" title="SEBRAE" width="303" height="51" />
    </div>

</section>
