<section class="container apoiadores">

    <h3 class="text-center mt-5" data-aos="fade-up" data-aos-duration="1000" data-aos-offset="0">Apoiadores</h3>

    <div class="text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-offset="0">
        <img src="{{ asset('img/logo-sebrae.svg') }}" alt="SEBRAE" title="SEBRAE" />
    </div>

</section>
