<section class="container-fluid programacao" id="programacao">

    <div class="container">

        <h2 class="text-light" data-aos="fade-right" data-aos-duration="1000" data-aos-anchor-placement="top-bottom">Programação do evento</h2>

        <p class="text-light subtitulo" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom">Veja o que espera por você na programação do COMICRO CONECTANDO NEGÓCIOS.<br>São várias trilhas de conhecimento para você pegar todas as dicas e aplicar na sua empresa.</p>

        <div data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom">
            <ul class="nav nav-pills nav-programacao" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="pills-cb-tab" data-bs-toggle="pill" data-bs-target="#pills-cb" type="button" role="tab" aria-controls="pills-cb" aria-selected="true">
                        <img src="{{ asset('img/logo-cb.png') }}" alt="Congresso Brasileiro de Micro e Pequenas Empresas" title="Congresso Brasileiro de Micro e Pequenas Empresas" width="183" height="47" />
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="pills-ce-tab" data-bs-toggle="pill" data-bs-target="#pills-ce" type="button" role="tab" aria-controls="pills-ce" aria-selected="false">
                        <img src="{{ asset('img/logo-ce.png') }}" alt="Congresso Estadual de Micro e Pequenas Empresas de Pernambuco" title="Congresso Estadual de Micro e Pequenas Empresas de Pernambuco" width="162" height="47" />
                    </button>
                </li>
{{--                <li class="nav-item" role="presentation">--}}
{{--                    <button class="nav-link" id="pills-ac-tab" data-bs-toggle="pill" data-bs-target="#pills-ac" type="button" role="tab" aria-controls="pills-ac" aria-selected="false">Arena Comicro</button>--}}
{{--                </li>--}}
{{--                <li class="nav-item" role="presentation">--}}
{{--                    <button class="nav-link" id="pills-ae-tab" data-bs-toggle="pill" data-bs-target="#pills-ae" type="button" role="tab" aria-controls="pills-ae" aria-selected="false">Atendimento Empresarial</button>--}}
{{--                </li>--}}
            </ul>

            <!-- CONGRESSO BRASILEIRO -->
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-cb" role="tabpanel" aria-labelledby="pills-cb-tab" tabindex="0">

                    <ul class="nav nav-pills nav-datas mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-cb16-tab" data-bs-toggle="pill" data-bs-target="#pills-cb16" type="button" role="tab" aria-controls="pills-cb16" aria-selected="true"><span>Dia 16/11 (Quinta-feira)</span></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-cb17-tab" data-bs-toggle="pill" data-bs-target="#pills-cb17" type="button" role="tab" aria-controls="pills-cb17" aria-selected="false"><span>Dia 17/11 (Sexta-feira)</span></button>
                        </li>
                    </ul>

                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-cb16" role="tabpanel" aria-labelledby="pills-cb16-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 10h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Abertura Solene</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 11h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Empreendedorismo</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 13h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Apresentação Cultural</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Tendências e estratégias de mercado</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 15h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Inovação e Transformação Digital</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->
                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 16h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Sustentabilidade e Meio Ambiente</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->
                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 17h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Legislação, Desburocratização e Simplificação</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->
                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Crédito, Investimento e Finanças</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->
                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 19h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Liderança e Produtividade</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                        <div class="tab-pane fade" id="pills-cb17" role="tabpanel" aria-labelledby="pills-cb17-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 10h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Liderança e Produtividade</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 11h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Crédito, Investimento e Finanças</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 13h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Apresentação Cultural</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Inovação de Transformação Digital</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Nacional</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 15h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Tendências e Estratégias de Mercado</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                    </div><!-- TAB CONTENT -->

                </div><!-- TAB PANE -->

                <!-- CONGRESSO ESTADUAL -->
                <div class="tab-pane fade" id="pills-ce" role="tabpanel" aria-labelledby="pills-ce-tab" tabindex="0">

                    <ul class="nav nav-pills nav-datas mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-ce17-tab" data-bs-toggle="pill" data-bs-target="#pills-ce17" type="button" role="tab" aria-controls="pills-ce17" aria-selected="true"><span>Dia 17/11 (Sexta-feira)</span></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-ce18-tab" data-bs-toggle="pill" data-bs-target="#pills-ce18" type="button" role="tab" aria-controls="pills-ce18" aria-selected="false"><span>Dia 18/11 (Sábado)</span></button>
                        </li>
                    </ul>

                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-ce17" role="tabpanel" aria-labelledby="pills-ce17-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 16h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Legislação, Desburocratização e Simplificação</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 17h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Sustentabilidade e Meio Ambiente</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Empreendedorismo</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 19h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Inovação e Transformação Digital</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                        <div class="tab-pane fade" id="pills-ce18" role="tabpanel" aria-labelledby="pills-ce18-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 10h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Empreendedorismo</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 11h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Inovação e Transformação Digital</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 13h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Apresentação Cultural</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Tendências e Estratégias de Mercado</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 15h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Crédito, Investimento e Finanças</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 16h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Liderança e Produtividade</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 17h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Tendências e Estratégias de Mercado</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Inovação e Transformação Digital</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Evento Estadual</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 19h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Empreendedorismo</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                    </div><!-- TAB CONTENT -->

                </div><!-- TAB PANE -->

                <!-- ARENA COMICRO -->
                <div class="tab-pane fade" id="pills-ac" role="tabpanel" aria-labelledby="pills-ac-tab" tabindex="0">

                    <ul class="nav nav-pills nav-datas mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-ac16-tab" data-bs-toggle="pill" data-bs-target="#pills-ac16" type="button" role="tab" aria-controls="pills-ac16" aria-selected="true"><span>Dia 16/11 (Quinta-feira)</span></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-ac17-tab" data-bs-toggle="pill" data-bs-target="#pills-ac17" type="button" role="tab" aria-controls="pills-ac17" aria-selected="true"><span>Dia 17/11 (Sexta-feira)</span></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-ac18-tab" data-bs-toggle="pill" data-bs-target="#pills-ac18" type="button" role="tab" aria-controls="pills-ac18" aria-selected="false"><span>Dia 18/11 (Sábado)</span></button>
                        </li>
                    </ul>

                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-ac16" role="tabpanel" aria-labelledby="pills-ac16-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 1</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 16h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 2</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 3</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                        <div class="tab-pane fade" id="pills-ac17" role="tabpanel" aria-labelledby="pills-ac17-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 10h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 4</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 12h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 5</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 6</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 7</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                        <div class="tab-pane fade" id="pills-ac18" role="tabpanel" aria-labelledby="pills-ac18-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 10h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 8</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 12h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 9</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 10</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 16h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 11</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Arena COMICRO</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Atividade 12</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                    </div><!-- TAB CONTENT -->

                </div><!-- TAB PANE -->

                <!-- ATENDIMENTO EMPRESARIAL -->
                <div class="tab-pane fade" id="pills-ae" role="tabpanel" aria-labelledby="pills-ae-tab" tabindex="0">

                    <ul class="nav nav-pills nav-datas mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-ae16-tab" data-bs-toggle="pill" data-bs-target="#pills-ae16" type="button" role="tab" aria-controls="pills-ae16" aria-selected="true"><span>Dia 16/11 (Quinta-feira)</span></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-ae17-tab" data-bs-toggle="pill" data-bs-target="#pills-ae17" type="button" role="tab" aria-controls="pills-ae17" aria-selected="true"><span>Dia 17/11 (Sexta-feira)</span></button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-ae18-tab" data-bs-toggle="pill" data-bs-target="#pills-ae18" type="button" role="tab" aria-controls="pills-ae18" aria-selected="false"><span>Dia 18/11 (Sábado)</span></button>
                        </li>
                    </ul>

                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-ae16" role="tabpanel" aria-labelledby="pills-ae16-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 10h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 11h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 12h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 13h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 15h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 16h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 17h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 19h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                        <div class="tab-pane fade" id="pills-ae17" role="tabpanel" aria-labelledby="pills-ae17-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 10h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 11h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 12h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 13h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 15h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 16h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 17h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 19h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                        <div class="tab-pane fade" id="pills-ae18" role="tabpanel" aria-labelledby="pills-ae18-tab" tabindex="0">

                            <div class="row">

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 10h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 11h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 12h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 13h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 14h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 15h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 16h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Rodada de Negócio</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 17h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 18h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                                <div class="col-md-6 col-programacao d-flex align-items-stretch">
                                    <div class="inner-programacao">
                                        <div class="row">
                                            <div class="col-lg-8">
                                                <span class="tag tag-evento text-uppercase">Atendimento Empresarial</span>
                                            </div>
                                            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                                                <span class="tag tag-horario text-uppercase">Horário: 19h</span>
                                            </div>
                                        </div>
                                        <h3 class="mt-3">Orientação Empresarial</h3>
                                    </div><!-- INNER-PRORAMACAO -->
                                </div><!-- COL -->

                            </div><!-- ROW -->

                        </div><!-- TAB PANE -->

                    </div><!-- TAB CONTENT -->

                </div><!-- TAB-PANE -->

            </div><!-- TAB CONTENT -->

            <div class="text-center text-md-start">
                <small class="text-light">*Programação sujeita à alteração</small>
            </div>

            <div class="my-5">

                <div class="text-center">
                    @component('front.layouts._components.btn_inscricao', ['class' => 'd-flex justify-content-center mt-5', 'link' => 'https://www.sympla.com.br/evento/comicro-conectando-negocios/2157093', 'rotulo' => 'INSCREVA-SE'])
                    @endcomponent
                </div><!-- COL -->

            </div><!-- ROW -->
        </div>

    </div><!-- CONTAINER -->

</section>
