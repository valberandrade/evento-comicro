<div class="{{ $class }}">
    <a href="{{ $link }}" class="btn btn-info btn-inscreva-se text-uppercase fw-bold" target="_blank">{{ $rotulo }}</a>
</div>
