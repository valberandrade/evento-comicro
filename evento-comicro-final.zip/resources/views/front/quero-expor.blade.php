@extends('.front.layouts.template')

{{--SEO--}}
@section('title', 'Quero Expor | COMICRO')
@section('meta_description', 'Por que Expor')
@section('site_url', '#')

{{--CONTENT--}}
@section('content')

    <!------------------- BANNER ---------------------->
    <section class="banner banner-quero-expor container-fluid">

        <div class="container">

            <div class="row d-flex align-items-center" data-aos="fade-left" data-aos-duration="1000">

                <div class="col-md-6 mb-5 mb-lg-0">
                    <h1>Por que Expor</h1>
                    <p>Amplie sua visibilidade, conquiste novos clientes e faça parcerias estratégicas em nosso evento.</p>

                    <p>Com uma audiência qualificada de potenciais compradores, empresários, investidores e líderes do mercado, a exposição de sua empresa é a oportunidade perfeita para alavancar seus negócios.</p>

                    <p>Não perca a oportunidade de se destacar no COMICRO Conectando Negócios e fortalecer sua presença de mercado. Garanta seu espaço hoje mesmo!</p>
                    <div class="buttons d-flex mt-5">
                        <a href="https://api.whatsapp.com/send?phone=5581981531166&text=Ol%C3%A1,%20gostaria%20de%20mais%20informa%C3%A7%C3%B5es%20sobre%20Stands%20no%20COMICRO%20Conectando%C2%A0Neg%C3%B3cios" class="btn btn-warning btn-vaga text-uppercase me-4">SOLICITAR VALORES</a>
                        <a href="https://api.whatsapp.com/send?phone=5581981531166&text=Ol%C3%A1,%20gostaria%20de%20mais%20informa%C3%A7%C3%B5es%20sobre%20Stands%20no%20COMICRO%20Conectando%C2%A0Neg%C3%B3cios" class="btn btn-outline-warning text-uppercase btn-saiba-mais">TIRAR DÚVIDAS</a>
                    </div><!-- BUTTONS -->
                </div><!-- COL -->

            </div><!-- ROW -->

        </div><!-- CONTAINER -->

    </section>


    <!------------------- STANDS ---------------------->
    @include('front.layouts._includes.stands')


    <!------------------- EXPOSITORES ---------------------->
    <section class="container-fluid card-expositores" id="expositores">

        <div class="container">

            <h2 class="text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom">Expositores</h2>

{{--            <div class="row" data-aos="fade-up" data-aos-duration="1000" data-aos-anchor-placement="top-bottom">--}}

{{--                @for($i = 1; $i <= 6; $i++)--}}
{{--                <div class="col-md-6 col-lg-4 mb-5">--}}
{{--                    <div class="card">--}}
{{--                        <div class="card-header text-center">--}}
{{--                            <img src="{{ asset('img/logos/logo-evernote.svg') }}" alt="" title="" width="164" height="48" />--}}
{{--                        </div>--}}
{{--                        <div class="card-body">--}}
{{--                            <div class="d-flex justify-content-between mb-3">--}}
{{--                                <span>E-mail:</span>--}}
{{--                                <a href="#" target="_blank">Enviar e-mail</a>--}}
{{--                            </div>--}}
{{--                            <div class="d-flex justify-content-between mb-3">--}}
{{--                                <span>Telefone:</span>--}}
{{--                                <a href="#" target="_blank">(81) 9 9999-9999</a>--}}
{{--                            </div>--}}
{{--                            <div class="d-flex justify-content-between mb-3">--}}
{{--                                <span>Site:</span>--}}
{{--                                <a href="#" target="_blank">Acessar</a>--}}
{{--                            </div>--}}
{{--                            <div class="d-flex justify-content-between mb-3">--}}
{{--                                <span>Redes sociais:</span>--}}
{{--                                <ul class="d-flex justify-content-end">--}}
{{--                                    <li>--}}
{{--                                        <a href="#" target="_blank">--}}
{{--                                            <img src="{{ asset('img/linkedin-roxo.svg') }}" alt="Linkedin" title="Linkedin" width="24" height="24" />--}}
{{--                                        </a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a href="#" target="_blank">--}}
{{--                                            <img src="{{ asset('img/instagram-roxo.svg') }}" alt="Instagram" title="Instagram" width="28" height="28" />--}}
{{--                                        </a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a href="#" target="_blank">--}}
{{--                                            <img src="{{ asset('img/twitter-roxo.svg') }}" alt="Twitter" title="Twitter" width="28" height="28" />--}}
{{--                                        </a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a href="#" target="_blank">--}}
{{--                                            <img src="{{ asset('img/facebook-roxo.svg') }}" alt="Facebook" title="Facebook" width="28" height="28" />--}}
{{--                                        </a>--}}
{{--                                    </li>--}}
{{--                                </ul>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div><!-- COL -->--}}
{{--                @endfor--}}

{{--            </div><!-- ROW -->--}}

        </div><!-- CONTAINER -->

    </section>



@endsection
